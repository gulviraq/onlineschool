import java.util.Scanner;

public class Validation {
    private Validation() {}

    public static String readNonEmptyString(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) return value;
            System.out.println("[Ошибка] Поле не может быть пустым. Повторите ввод.");
        }
    }

    public static int readInt(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("[Ошибка] Введите целое число от " + min + " до " + max + ".");
        }
    }

    public static double readDouble(Scanner scanner, String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim().replace(',', '.');
            try {
                double value = Double.parseDouble(line);
                if (Double.isFinite(value) && value >= min && value <= max) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("[Ошибка] Введите число от " + min + " до " + max + ".");
        }
    }

    public static boolean readYesNo(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt + " (да/нет): ");
            String value = scanner.nextLine().trim().toLowerCase();
            if (value.equals("да") || value.equals("д") || value.equals("yes") || value.equals("y")) return true;
            if (value.equals("нет") || value.equals("н") || value.equals("no") || value.equals("n")) return false;
            System.out.println("[Ошибка] Введите «да» или «нет».");
        }
    }
}
