import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ContentItem {
    public enum Type { СТАТЬЯ, ВИДЕО, ФОТО }

    private final int id;
    private final Type type;
    private final String title;
    private final String description;
    private final String resource;
    private final String author;
    private final LocalDateTime createdAt;

    public ContentItem(int id, Type type, String title, String description, String resource, String author) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.description = description;
        this.resource = resource;
        this.author = author;
        this.createdAt = LocalDateTime.now();
    }

    public int getId() { return id; }

    @Override
    public String toString() {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        return "[" + type + " #" + id + "] " + title + "\n"
                + description + "\n"
                + "Материал: " + resource + "\n"
                + "Автор: " + author + " | " + createdAt.format(f);
    }
}
