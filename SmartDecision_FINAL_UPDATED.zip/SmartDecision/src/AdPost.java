public class AdPost {
    private final String title;
    private final String text;
    private final String link;
    private final boolean active;

    public AdPost(String title, String text, String link, boolean active) {
        this.title = title;
        this.text = text;
        this.link = link;
        this.active = active;
    }

    public boolean isActive() { return active; }

    @Override
    public String toString() {
        return "================ РЕКЛАМА ================\n"
                + title.toUpperCase() + "\n"
                + text + "\n"
                + "Подробнее: " + link + "\n"
                + "==========================================";
    }
}
