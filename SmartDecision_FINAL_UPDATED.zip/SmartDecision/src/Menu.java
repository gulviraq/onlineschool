import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Menu {
    private final Scanner scanner = new Scanner(System.in);
    private final DecisionSystem system = new DecisionSystem();
    private String currentUser = "Гость";
    private boolean authenticated = false;
    private final List<ContentItem> content = new ArrayList<>();
    private final List<AdPost> advertisements = new ArrayList<>();
    private int nextContentId = 1;

    public void start() {
        System.out.println("Добро пожаловать в образовательную платформу SmartDecision!");
        while (true) {
            printMenu();
            int choice = Validation.readInt(scanner, "Выберите раздел (0-14): ", 0, 14);
            switch (choice) {
                case 1: authenticate(); break;
                case 2: studentStatus(); break;
                case 3: ageCheck(); break;
                case 4: discountCalculator(); break;
                case 5: financeCheck(); break;
                case 6: testEvaluation(); break;
                case 7: securityCheck(); break;
                case 8: serviceMenu(); break;
                case 9: recommendationMenu(); break;
                case 10: readinessAnalysis(); break;
                case 11: combinedScenarios(); break;
                case 12: adminPanel(); break;
                case 13: showContentFeed(); break;
                case 14: showAdvertisements(); break;
                case 0:
                    System.out.println("Работа SmartDecision завершена. До свидания!");
                    return;
                default: System.out.println("[Ошибка] Такого раздела нет. Повторите выбор.");
            }
            System.out.println("\nНажмите Enter, чтобы вернуться в главное меню...");
            scanner.nextLine();
        }
    }

    private void printMenu() {
        System.out.println("\n+--------------------------------------------------+");
        System.out.println("|             SmartDecision — ГЛАВНОЕ МЕНЮ        |");
        System.out.println("+--------------------------------------------------+");
        System.out.println("| 1. Авторизация пользователя                      |");
        System.out.println("| 2. Проверка статуса студента                     |");
        System.out.println("| 3. Возрастные категории                          |");
        System.out.println("| 4. Расчёт скидки                                 |");
        System.out.println("| 5. Анализ финансового состояния                  |");
        System.out.println("| 6. Оценка результатов теста                      |");
        System.out.println("| 7. Проверка безопасности                         |");
        System.out.println("| 8. Категории услуг и калькулятор стоимости       |");
        System.out.println("| 9. Персональные рекомендации                     |");
        System.out.println("|10. Индивидуальный анализ готовности              |");
        System.out.println("|11. Комплексные сценарии решений                   |");
        System.out.println("|12. Личный кабинет / Админ-панель                  |");
        System.out.println("|13. Лента статей, видео и фото                     |");
        System.out.println("|14. Рекламные посты                                |");
        System.out.println("| 0. Выход                                         |");
        System.out.println("+--------------------------------------------------+");
        System.out.println("Пользователь: " + currentUser + (authenticated ? " [авторизован]" : " [гостевой режим]"));
    }

    private void authenticate() {
        System.out.println("\n--- Авторизация ---");
        String login = Validation.readNonEmptyString(scanner, "Логин: ");
        String password = Validation.readNonEmptyString(scanner, "Пароль: ");
        if (system.checkLogin(login, password)) {
            authenticated = true;
            currentUser = login;
            System.out.println("[Успех] Доступ разрешён. Добро пожаловать!");
        } else {
            authenticated = false;
            currentUser = "Гость";
            System.out.println("[Предупреждение] Неверный логин или пароль. Доступ не предоставлен.");
        }
    }

    private void studentStatus() {
        System.out.println("\n--- Проверка статуса студента ---");
        String name = Validation.readNonEmptyString(scanner, "Имя студента: ");
        int attendance = Validation.readInt(scanner, "Посещаемость (0-100%): ", 0, 100);
        boolean blocked = Validation.readYesNo(scanner, "Студент заблокирован?");
        String status = system.checkStudentStatus(attendance, blocked);
        System.out.println(name + " — " + status);
        if (!blocked) System.out.println("Проверка !заблокирован: пользователь может пользоваться системой.");
    }

    private void ageCheck() {
        System.out.println("\n--- Возрастная категория ---");
        int age = Validation.readInt(scanner, "Возраст (0-120): ", 0, 120);
        System.out.println("Категория: " + system.ageCategory(age));
    }

    private void discountCalculator() {
        System.out.println("\n--- Расчёт скидки ---");
        double purchase = Validation.readDouble(scanner, "Сумма покупки (тг): ", 0, 100000000);
        String status = Validation.readNonEmptyString(scanner, "Статус клиента (обычный/VIP): ");
        if (!status.equalsIgnoreCase("VIP") && !status.equalsIgnoreCase("обычный")) {
            System.out.println("Неизвестный статус — применён обычный тариф.");
            status = "обычный";
        }
        double discount = system.calculateDiscount(purchase, status);
        System.out.printf("Скидка: %.0f%% | К оплате: %.2f тг%n", discount, purchase * (1 - discount / 100));
    }

    private void financeCheck() {
        System.out.println("\n--- Финансовый анализ ---");
        double income = Validation.readDouble(scanner, "Доходы за месяц (тг): ", 0, 1000000000);
        double expenses = Validation.readDouble(scanner, "Расходы за месяц (тг): ", 0, 1000000000);
        System.out.println("Финансовый статус: " + system.financialStatus(income, expenses));
        System.out.printf("Баланс: %.2f тг%n", income - expenses);
    }

    private void testEvaluation() {
        System.out.println("\n--- Оценка теста ---");
        String name = Validation.readNonEmptyString(scanner, "ФИО студента: ");
        int score = Validation.readInt(scanner, "Баллы (0-100): ", 0, 100);
        System.out.println(name + ": " + system.evaluateTestScore(score));
    }

    private void securityCheck() {
        System.out.println("\n--- Проверка безопасности ---");
        int attempts = Validation.readInt(scanner, "Количество неудачных входов (0-10): ", 0, 10);
        boolean unusual = Validation.readYesNo(scanner, "Вход из необычного местоположения?");
        boolean strong = Validation.readYesNo(scanner, "Пароль надёжный?");
        String risk = system.securityRisk(attempts, unusual, strong);
        System.out.println("Уровень риска: " + risk);
        if (risk.equals("Высокий риск")) System.out.println("Рекомендация: временно ограничить вход и сменить пароль.");
        else if (risk.equals("Средний риск")) System.out.println("Рекомендация: включить дополнительную проверку входа.");
        else System.out.println("Рекомендация: продолжить стандартный мониторинг.");
    }

    private void serviceMenu() {
        System.out.println("\n--- Категории услуг ---");
        System.out.println("1. Самостоятельное обучение\n2. Групповое обучение\n3. Индивидуальное обучение\n4. Подготовка к экзаменам\n5. Карьерный трек");
        int category = Validation.readInt(scanner, "Категория (1-5): ", 1, 5);
        System.out.println(system.serviceCategory(category));
        System.out.println("Тарифы: 1 — Базовый (15000 тг), 2 — Стандарт (30000 тг), 3 — VIP (50000 тг)");
        int tariff = Validation.readInt(scanner, "Выберите тариф (1-3): ", 1, 3);
        int hours = Validation.readInt(scanner, "Дополнительные часы (0-100): ", 0, 100);
        boolean materials = Validation.readYesNo(scanner, "Добавить учебные материалы за 5000 тг?");
        double total = system.calculateServicePrice(tariff, hours, materials);
        System.out.printf("Итоговая стоимость: %.2f тг%n", total);
    }

    private void recommendationMenu() {
        System.out.println("\n--- Персональные рекомендации ---");
        int age = Validation.readInt(scanner, "Возраст (7-100): ", 7, 100);
        int level = Validation.readInt(scanner, "Уровень курса (1 — базовый, 2 — продвинутый): ", 1, 2);
        boolean experience = Validation.readYesNo(scanner, "Есть опыт программирования?");
        int attendance = Validation.readInt(scanner, "Посещаемость (0-100%): ", 0, 100);
        int score = Validation.readInt(scanner, "Последний тест (0-100): ", 0, 100);
        String ageGroup = system.ageCategory(age);
        String status = system.checkStudentStatus(attendance, false);
        String advice = system.recommendation(experience, level, attendance, score);
        System.out.println("Возрастная группа: " + ageGroup);
        System.out.println("Статус: " + status);
        System.out.println(advice);
        Report.printReport(currentUser, age, ageGroup, status, system.evaluateTestScore(score), advice);
    }

    private void readinessAnalysis() {
        System.out.println("\n--- Индивидуальный модуль: готовность к интенсиву ---");
        int attendance = Validation.readInt(scanner, "Посещаемость (0-100%): ", 0, 100);
        int score = Validation.readInt(scanner, "Средний балл тестов (0-100): ", 0, 100);
        int hours = Validation.readInt(scanner, "Часов самостоятельной учёбы в неделю (0-40): ", 0, 40);
        int tasks = Validation.readInt(scanner, "Выполнено практических заданий (0-20): ", 0, 20);
        int motivation = Validation.readInt(scanner, "Самооценка мотивации (1-10): ", 1, 10);
        boolean device = Validation.readYesNo(scanner, "Есть компьютер или ноутбук?");
        String analysis = system.analyzeReadiness(attendance, score, hours, tasks, motivation, device);
        String advice = system.readinessRecommendation(attendance, score, hours, tasks, motivation, device);
        System.out.println("Итог: " + analysis);
        System.out.println("Персональная рекомендация: " + advice);
        Report.printReport(currentUser, 0, "Не указана", "Анализ обучающегося", analysis, advice);
    }

    // Личный кабинет администратора: управление материалами и рекламой.
    private void adminPanel() {
        if (!authenticated) {
            System.out.println("[Доступ запрещён] Сначала авторизуйтесь как администратор.");
            return;
        }
        while (true) {
            System.out.println("\n--- ЛИЧНЫЙ КАБИНЕТ / АДМИН-ПАНЕЛЬ ---");
            System.out.println("1. Добавить статью");
            System.out.println("2. Добавить видео");
            System.out.println("3. Добавить фото");
            System.out.println("4. Добавить рекламный пост");
            System.out.println("5. Посмотреть опубликованный контент");
            System.out.println("6. Посмотреть рекламу");
            System.out.println("0. Назад");
            int choice = Validation.readInt(scanner, "Выберите действие (0-6): ", 0, 6);
            if (choice == 0) return;
            switch (choice) {
                case 1: addContent(ContentItem.Type.СТАТЬЯ); break;
                case 2: addContent(ContentItem.Type.ВИДЕО); break;
                case 3: addContent(ContentItem.Type.ФОТО); break;
                case 4: addAdvertisement(); break;
                case 5: showContentFeed(); break;
                case 6: showAdvertisements(); break;
            }
        }
    }

    private void addContent(ContentItem.Type type) {
        System.out.println("\n--- Добавление: " + type + " ---");
        String title = Validation.readNonEmptyString(scanner, "Заголовок: ");
        String description = Validation.readNonEmptyString(scanner, "Описание/текст: ");
        String resource = Validation.readNonEmptyString(scanner, "Ссылка или путь к материалу: ");
        content.add(new ContentItem(nextContentId++, type, title, description, resource, currentUser));
        System.out.println("[Успех] Материал опубликован в ленте.");
    }

    private void addAdvertisement() {
        System.out.println("\n--- Добавление рекламного поста ---");
        String title = Validation.readNonEmptyString(scanner, "Заголовок рекламы: ");
        String text = Validation.readNonEmptyString(scanner, "Текст рекламы: ");
        String link = Validation.readNonEmptyString(scanner, "Ссылка/контакт: ");
        advertisements.add(new AdPost(title, text, link, true));
        System.out.println("[Успех] Рекламный пост опубликован.");
    }

    private void showContentFeed() {
        System.out.println("\n========== ЛЕНТА ОНЛАЙН-ШКОЛЫ ==========");
        if (content.isEmpty()) {
            System.out.println("Пока нет опубликованных статей, видео или фото.");
        } else {
            for (ContentItem item : content) {
                System.out.println(item);
                System.out.println("------------------------------------------");
            }
        }
        // Нативный рекламный блок внутри ленты, по аналогии с рекламными вставками на медиасайтах.
        for (AdPost ad : advertisements) {
            if (ad.isActive()) System.out.println(ad);
        }
    }

    private void showAdvertisements() {
        System.out.println("\n========== РЕКЛАМНЫЕ ПОСТЫ ==========");
        if (advertisements.isEmpty()) {
            System.out.println("Активной рекламы пока нет.");
            return;
        }
        for (AdPost ad : advertisements) {
            if (ad.isActive()) System.out.println(ad);
        }
    }

    private void combinedScenarios() {
        System.out.println("\n--- Комплексная система решений (switch + if/else + логика) ---");
        System.out.println("1. Допуск к экзамену\n2. Доступ к интенсиву\n3. Стипендия\n4. Поддержка студента\n5. Доступ к проектной лаборатории");
        int scenario = Validation.readInt(scanner, "Сценарий (1-5): ", 1, 5);
        int attendance = Validation.readInt(scanner, "Посещаемость (0-100%): ", 0, 100);
        int score = Validation.readInt(scanner, "Средний балл (0-100): ", 0, 100);
        boolean debt = Validation.readYesNo(scanner, "Есть академическая задолженность?");
        boolean active = Validation.readYesNo(scanner, "Студент активен?");
        String result;
        switch (scenario) {
            case 1:
                if (attendance >= 70 && score >= 50 && !debt) result = "Допущен к экзамену";
                else result = "Не допущен: проверьте посещаемость, баллы и задолженности";
                break;
            case 2:
                if (active && (score >= 70 || attendance >= 90)) result = "Доступ к интенсиву открыт";
                else result = "Сначала улучшите активность или учебные показатели";
                break;
            case 3:
                if (score >= 90 && attendance >= 85 && !debt) result = "Кандидат на повышенную стипендию";
                else if (score >= 75 && attendance >= 75 && !debt) result = "Кандидат на стандартную стипендию";
                else result = "Условия стипендии пока не выполнены";
                break;
            case 4:
                if (score < 50) {
                    if (attendance < 60) result = "Назначить куратора и план восстановления посещаемости";
                    else result = "Назначить дополнительные занятия по предмету";
                } else result = "Достаточно стандартной поддержки";
                break;
            case 5:
                if (active && !debt) {
                    if (score >= 80) result = "Полный доступ к проектной лаборатории";
                    else result = "Доступ к лаборатории с наставником";
                } else result = "Доступ временно ограничен";
                break;
            default: result = "Неизвестный сценарий";
        }
        System.out.println("Решение системы: " + result);
    }
}
