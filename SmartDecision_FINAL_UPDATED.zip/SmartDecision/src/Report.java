import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Report {
    public static void printReport(String username, int age, String ageCategory,
                                   String studentStatus, String analysis, String recommendation) {
        System.out.println("\n====================================================");
        System.out.println("             ИТОГОВЫЙ ОТЧЁТ SmartDecision");
        System.out.println("====================================================");
        System.out.println("Дата и время: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")));
        System.out.println("Пользователь: " + username);
        System.out.println("Возраст: " + (age > 0 ? age + " лет (" + ageCategory + ")" : "не указан"));
        System.out.println("Статус: " + studentStatus);
        System.out.println("Результат анализа: " + analysis);
        System.out.println("Рекомендация: " + recommendation);
        System.out.println("====================================================\n");
    }
}
