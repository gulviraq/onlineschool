public class DecisionSystem {
    public boolean checkLogin(String username, String password) {
        return "teacher".equals(username) && "2026".equals(password);
    }

    public String checkStudentStatus(int attendance, boolean blocked) {
        if (blocked) return "Заблокирован (доступ закрыт)";
        if (attendance >= 80) return "Активный";
        if (attendance >= 50) return "Неактивный (требуется внимание)";
        return "В зоне риска (низкая посещаемость)";
    }

    public String ageCategory(int age) {
        if (age < 7) return "Дошкольный возраст";
        else if (age < 13) return "Младшая возрастная категория";
        else if (age < 18) return "Подростковая категория";
        else if (age < 60) return "Совершеннолетний";
        return "Взрослый пользователь";
    }

    public double calculateDiscount(double purchase, String customerStatus) {
        double discount = 0;
        if (purchase >= 100000 && customerStatus.equalsIgnoreCase("VIP")) discount = 20;
        else if (purchase >= 50000 || customerStatus.equalsIgnoreCase("VIP")) discount = 15;
        else if (purchase >= 20000) discount = 10;
        else if (purchase >= 10000) discount = 5;
        return discount;
    }

    public String financialStatus(double income, double expenses) {
        if (income <= 0) return "Критическое состояние: доход должен быть положительным";
        double balance = income - expenses;
        if (balance < 0) return "Дефицит бюджета";
        if (balance < income * 0.15) return "Нестабильное состояние";
        return "Финансово устойчивое состояние";
    }

    public String evaluateTestScore(int score) {
        if (score < 50) return "Незачёт — рекомендуется пересдача";
        else if (score < 75) return "Удовлетворительно";
        else if (score < 90) return "Хорошо";
        return "Отлично";
    }

    public String securityRisk(int failedLogins, boolean unusualLocation, boolean strongPassword) {
        int risk = failedLogins * 2 + (unusualLocation ? 3 : 0) + (!strongPassword ? 3 : 0);
        if (risk >= 7) return "Высокий риск";
        if (risk >= 3) return "Средний риск";
        return "Низкий риск";
    }

    public String recommendation(boolean experience, int level, int attendance, int score) {
        if (attendance < 50) return "Сначала восстановить регулярное посещение и пройти вводные занятия.";
        if (score < 50) return "Повторить основы, воспользоваться консультацией преподавателя и пересдать тест.";
        if (experience && level == 2 && score >= 75) return "Продвинутый курс Java, алгоритмы и Spring Boot.";
        if (!experience && level == 1) return "Базовый курс Java для начинающих с практическими заданиями.";
        return "Пройти вводный интенсив и затем выбрать курс по результатам диагностики.";
    }

    public String serviceCategory(int category) {
        switch (category) {
            case 1: return "Самостоятельное обучение: видеокурсы и тесты";
            case 2: return "Групповое обучение: занятия с преподавателем";
            case 3: return "Индивидуальное обучение: персональный план";
            case 4: return "Подготовка к экзаменам: пробные тесты и разбор";
            case 5: return "Карьерный трек: проекты и портфолио";
            default: return "Неизвестная категория";
        }
    }

    public double calculateServicePrice(int tariff, int extraHours, boolean materials) {
        double base;
        switch (tariff) {
            case 1: base = 15000; break;
            case 2: base = 30000; break;
            case 3: base = 50000; break;
            default: base = -1;
        }
        if (base < 0) return -1;
        return base + extraHours * 3000 + (materials ? 5000 : 0);
    }

    // Индивидуальный модуль: оценка готовности студента к интенсивному курсу.
    public String analyzeReadiness(int attendance, int score, int studyHours,
                                   int completedTasks, int motivation, boolean hasDevice) {
        int points = 0;
        if (attendance >= 80) points += 2;
        if (score >= 70) points += 2;
        if (studyHours >= 5) points += 2;
        if (completedTasks >= 8) points += 2;
        if (motivation >= 7) points += 2;
        if (hasDevice) points += 2;
        if (attendance >= 60 && score >= 50) points++;
        if (studyHours >= 3 && motivation >= 5) points++;
        if (points >= 10) return "ВЫСОКИЙ уровень готовности (" + points + "/14)";
        if (points >= 6) return "СРЕДНИЙ уровень готовности (" + points + "/14)";
        return "НИЗКИЙ уровень готовности (" + points + "/14)";
    }

    public String readinessRecommendation(int attendance, int score, int studyHours,
                                           int completedTasks, int motivation, boolean hasDevice) {
        StringBuilder result = new StringBuilder();
        if (attendance < 80) result.append("Увеличить посещаемость. ");
        if (score < 70) result.append("Повторить темы и улучшить результат теста. ");
        if (studyHours < 5) result.append("Выделять не менее 5 часов на учёбу в неделю. ");
        if (completedTasks < 8) result.append("Выполнить дополнительные практические задания. ");
        if (motivation < 7) result.append("Составить личную учебную цель и план. ");
        if (!hasDevice) result.append("Обеспечить доступ к компьютеру или ноутбуку. ");
        if (result.length() == 0) result.append("Сохранить темп и перейти к продвинутому курсу.");
        return result.toString().trim();
    }
}
